# @apet97/clockify-mcp-115

TypeScript stdio MCP server for Clockify, built on
`clockify-sdk-ts-115`. It is the Node sibling to
[`apet97/go-clockify`](https://github.com/apet97/go-clockify): one
local user, one pinned `CLOCKIFY_WORKSPACE_ID`, workflow tools first,
domain CRUD second.

Current release: `2.0.0`. Requires Node.js `>=22.13.0` and
`clockify-sdk-ts-115 ^2`.

This package now advertises 162 tools: 22 workflow tools plus 140
domain tools across Clockify's major resources. It is published to npm
under the unofficial `@apet97` scope; the `prepublishOnly` gates run on
every publish.

Product posture: this is the pure-Node, SDK-vendor-style MCP sibling to
the Go reference server. Keep it workflow-first, easy to install, and
strict about receipts (`ids`, `changed`, `next`, stable errors,
recovery). For the repo-level quality bar, see
[`docs/product-north-star.md`](../docs/product-north-star.md).

`clockify_entity_changes_list` is an explicitly experimental read surface. Its
required `changeType` selects exactly one created, updated, or deleted generated
endpoint per call; responses are returned unchanged with an experimental API
warning, not merged into a synthetic audit timeline.

New here? See [how this compares to other Clockify MCP servers and the first-run path](./POSITIONING.md).

## Install

The fastest path is the one-click bundle. A manual MCP-client config and a
build-from-source flow follow for other setups.

### One-click (recommended)

Download
[`clockify115-mcp-0.8.0.mcpb`](https://github.com/apet97/clockify-ts-sdk/releases/download/mcp-v0.8.0/clockify115-mcp-0.8.0.mcpb)
from the [`mcp-v0.8.0` release](https://github.com/apet97/clockify-ts-sdk/releases/tag/mcp-v0.8.0)
and open it with Claude Desktop. For just the `clockify115-mcp` binary, run
`npm i -g @apet97/clockify-mcp-115` (unofficial, under the `@apet97` scope). To
build the same bundle from a clone instead:

```sh
make mcpb
```

This writes `mcp/clockify115-mcp-<version>.mcpb`, a self-contained bundle you can
open with Claude Desktop the same way.

Maintainers should run `make mcpb-smoke` before attaching the bundle to a GitHub
Release. Routine local gates run `make mcpb-validate`, which checks the manifest
without producing the binary bundle.

### Manual MCP client config

If your MCP client reads an `mcpServers` config instead of an `.mcpb`, use the
JSON block in [Configure](#configure). Note that `"command": "clockify115-mcp"`
requires the binary to be on your `PATH` first — install the package globally or
`npm link` it from a source build (below). Otherwise point `command` at an
absolute path: `node /absolute/path/to/mcp/dist/index.js`.

### Build from source

For development, or to produce the `clockify115-mcp` binary for the manual config
above:

```sh
npm ci && make sdk-codegen              # from the repo root, once
npm run build -w clockify-sdk-ts-115    # build the workspace-linked SDK
cd mcp
npm install
npm run build
npm link
```

This builds the server against `clockify-sdk-ts-115` and links the
`clockify115-mcp` binary onto your `PATH`.

### Where to get your two values

- **API key**: Clockify -> Profile -> **API**, then generate a key.
- **Workspace id**: the 24-character id in your Clockify URL after
  `/workspaces/`.

### Verify it works

Ask your assistant to call `clockify_status`. It should report your user, your
workspace, and any running timer.

## Configure

The server reads `CLOCKIFY_API_KEY` and `CLOCKIFY_WORKSPACE_ID` from
its process environment. `CLOCKIFY_BASE_URL` is optional and should
only be used for mock/replay gateways or private test environments.
Code that calls `loadContext()` directly can opt into a trusted non-Clockify
HTTPS proxy with `allowNonClockifyHttpsHost: true`; cleartext non-loopback
destinations remain rejected.

Optional `CLOCKIFY_REGION` (`global`, `eu`, `us`, `uk`, `au`, or `developer`)
selects a Clockify routing profile; optional `CLOCKIFY_SUBDOMAIN` selects a
workspace subdomain and requires `CLOCKIFY_REGION` to be `eu`/`us`/`uk`/`au`.
Both are mutually exclusive with `CLOCKIFY_BASE_URL`. Only the `global`
profile is live-confirmed; setting any other `CLOCKIFY_REGION` is itself
the acknowledgement that its route is unproven for data residency.

```json
{
    "mcpServers": {
        "clockify": {
            "command": "clockify115-mcp",
            "env": {
                "CLOCKIFY_API_KEY": "your_key_here",
                "CLOCKIFY_WORKSPACE_ID": "your_workspace_id_here"
            }
        }
    }
}
```

## Workflow Tools

<!-- BEGIN generated:mcp-workflow-tools -->
| Tool | Purpose |
|---|---|
| `clockify_status` | Confirm user, workspace, and running timer. |
| `clockify_doctor` | Live preflight: validate the API key, workspace pin, base-URL posture, and clock skew (read-only). |
| `clockify_tools_guide` | Show workflow groups and when to use domain tools. |
| `clockify_plan_change` | Explain which tools a change will use, in order, before mutating (read-only). |
| `clockify_docs_search` | Search compact SDK/CLI/MCP guidance for agents (read-only). |
| `clockify_operation_guide` | Map a task, operation, or tool to recommended paths (read-only). |
| `clockify_sdk_snippet` | Return a compact SDK, CLI, or MCP snippet for a task (read-only). |
| `clockify_create_work_package` | Create or reuse client, project, task, and tag objects. |
| `clockify_log_work` | Log a finished time entry from names or IDs. |
| `clockify_start_work` | Start a running work timer. |
| `clockify_stop_work` | Stop the current running timer. |
| `clockify_switch_work` | Stop current work and start another timer. |
| `clockify_review_day` | Review daily totals, running timers, and missing fields. |
| `clockify_review_week` | Review weekly totals and issues. |
| `clockify_fix_entry` | Find one entry and update selected fields. |
| `clockify_invoice_client_work` | Create a draft invoice for a client. |
| `clockify_record_expense` | Prepare or record an expense with resolved names. |
| `clockify_request_time_off` | Create a time-off request from a policy name or ID. |
| `clockify_schedule_work` | Create a scheduling assignment from user/project names or IDs. |
| `clockify_setup_webhook` | Create a validated HTTPS webhook subscription. |
| `clockify_demo_seed` | Create deterministic demo objects. |
| `clockify_demo_cleanup` | Clean deterministic demo entries and objects by prefix. |
<!-- END generated:mcp-workflow-tools -->

## Workflow Examples

Create reusable work objects:

```json
{
    "name": "clockify_create_work_package",
    "arguments": {
        "client": "Acme",
        "project": "Website",
        "task": "Implementation",
        "tag": "Deep Work",
        "billable": true
    }
}
```

Log finished work:

```json
{
    "name": "clockify_log_work",
    "arguments": {
        "start": "2026-05-26T09:00:00Z",
        "end": "2026-05-26T10:15:00Z",
        "description": "Implemented Clockify workflow tools",
        "project_id": "PROJECT_ID",
        "task_id": "TASK_ID",
        "tag_ids": ["TAG_ID"]
    }
}
```

Start, stop, and switch timers:

```json
{ "name": "clockify_start_work", "arguments": { "project": "Website", "description": "Bugfixing" } }
{ "name": "clockify_stop_work", "arguments": {} }
{ "name": "clockify_switch_work", "arguments": { "project": "API", "description": "Review" } }
```

Review and fix:

```json
{ "name": "clockify_review_day", "arguments": { "date": "2026-05-26", "include_entries": true } }
{ "name": "clockify_review_week", "arguments": { "week_start": "2026-05-26" } }
{ "name": "clockify_fix_entry", "arguments": { "entry_id": "ENTRY_ID", "new_description": "Corrected description" } }
```

Every tool publishes a risk class at
`_meta["io.github.apet97.clockify115/risk"]` and its confirmation mode at
`_meta["io.github.apet97.clockify115/confirmation"]`. Read and routine writes
remain one-call operations. Business writes, external side effects, privileged
writes, and destructive writes are two-step operations: run with `dry_run:true`
first, then re-run the same business arguments with the short-lived, single-use
`confirm_token`. The token executes the exact stored preview instead of resolving
or rebuilding it again.

Cancellation propagates to the active Clockify request, and a multi-step tool
does not start its next request after cancellation. A request cancelled before
execution begins does not consume its confirmation token. Once a confirmed
mutation may have begun, however, its single-use token stays consumed because
the remote outcome can be ambiguous; run a fresh `dry_run` before trying again.

```json
{
    "name": "clockify_invoice_client_work",
    "arguments": {
        "client": "Acme",
        "currency": "USD",
        "issued_date": "2026-05-26",
        "due_date": "2026-06-09",
        "dry_run": true
    }
}
```

```json
{
    "name": "clockify_record_expense",
    "arguments": {
        "amount": 42.5,
        "category": "Travel",
        "project": "Website",
        "notes": "Taxi to customer site",
        "dry_run": true
    }
}
```

```json
{
    "name": "clockify_request_time_off",
    "arguments": {
        "policy": "Vacation",
        "start": "2026-06-01",
        "end": "2026-06-03",
        "note": "Family trip",
        "dry_run": true
    }
}
```

```json
{
    "name": "clockify_schedule_work",
    "arguments": {
        "user": "alice@example.com",
        "project": "Website",
        "start": "2026-05-27",
        "end": "2026-05-31",
        "hours_per_day": 6,
        "dry_run": true
    }
}
```

```json
{
    "name": "clockify_setup_webhook",
    "arguments": {
        "name": "Time entry audit",
        "url": "https://example.com/clockify",
        "webhook_event": "NEW_TIME_ENTRY",
        "dry_run": true
    }
}
```

Demo fixture helpers:

```json
{ "name": "clockify_demo_seed", "arguments": { "run_id": "smoke" } }
{ "name": "clockify_demo_cleanup", "arguments": { "run_id": "smoke", "dry_run": true } }
{ "name": "clockify_demo_cleanup", "arguments": { "run_id": "smoke", "confirm_token": "TOKEN_FROM_PREVIEW" } }
```

`clockify_demo_seed` and `clockify_demo_cleanup` ship by default rather
than behind a flag: they participate in the root `make perfect-live`
sandbox proof that all SDK/CLI/MCP/GOCLMCP surfaces leave zero objects
behind. `demo_seed`
creates only prefix-namespaced objects, and `clockify_demo_cleanup` requires a
stored-preview confirmation token and publishes `destructiveHint:true` so a
client surfaces it as destructive before execution.

## Resources and Prompts

The server exposes guide resources for agent discovery:

- `clockify://guide/axioms` — product axioms and safety boundaries.
- `clockify://guide/workflows` — workflow-first guidance and tool sequencing.
- `clockify://guide/safety` — write-safety rules including dry_run and confirm_token.
- `clockify://guide/agent-mode` — when to use the read-only discovery tools.
- `clockify://guide/which-tool` — intent → first-tool decision tree across time tracking, billing, and admin.
- `clockify://mcp/doctor` — No-network diagnostics checklist for local readiness.

The read-only `clockify_docs_search`, `clockify_operation_guide`, and
`clockify_sdk_snippet` tools help an agent pick the smallest correct SDK, CLI,
or MCP path before touching live data.

Prompts:

- `clockify-workflow-plan` — interactive workflow plan for time tracking and admin flows.
- `clockify-getting-started` — first-run setup walkthrough from API key and workspace to your first logged entry.

## Naming

Tools follow two grammars. **Workflow tools** read as action
verb-phrases (`clockify_log_work`, `clockify_review_day`,
`clockify_create_work_package`) so an agent picks them by intent.
**Domain tools** follow `clockify_<group>_<action>`
(`clockify_projects_create`, `clockify_entries_delete`) to mirror the
underlying Clockify resource. The canonical rules — and how they map to
SDK methods, CLI commands, and OpenAPI operations — live in
[`docs/naming-taxonomy-policy.md`](../docs/naming-taxonomy-policy.md),
the source of truth.

## Domain Tools

<!-- BEGIN generated:mcp-domain-tools -->
| Resource group | Count | Tools |
|---|---:|---|
| `clients` | 5 | list, get, create, update, delete |
| `projects` | 11 | list, get, create, update, delete, set_member_rate, memberships_list, memberships_update, estimates_update, templates_list, templates_mark |
| `tasks` | 6 | list, get, create, update, delete, set_rate |
| `tags` | 5 | list, get, create, update, delete |
| `entries` | 7 | list, get, get_many, log, update, delete, mark_invoiced |
| `timer` | 2 | start, stop |
| `invoices` | 14 | list, get, create, update, delete, update_status, import_time, info, items_list, items_add, items_delete, payments_list, payments_create, payments_delete |
| `expenses` | 10 | expense list/get/create/update/delete; category CRUD plus archive |
| `webhooks` | 7 | list, get, delivery_diagnose, create, update, delete, events |
| `custom_fields` | 7 | workspace CRUD plus project field list/update/remove |
| `time_off` | 18 | requests (incl. for another user), policies, balance reads/update, and balance assignments |
| `users` | 8 | list, member_profile_get, grant_role, revoke_role, set_status, set_member_rate, invite, member_profile_update |
| `scheduling` | 8 | assignments list/create/update/delete/copy plus publish and capacity |
| `reports` | 5 | summary, detailed, weekly, attendance, expense |
| `shared_reports` | 5 | list, view, create, update, delete |
| `groups` | 8 | CRUD plus membership tools |
| `holidays` | 5 | list/create/update/delete |
| `approvals` | 6 | list, submit, submit with type, submit for user with type, update state, resubmit |
| `audit_log` | 1 | search |
| `entity_changes` | 1 | list (experimental, changeType-routed) |
| `workspace` | 1 | settings (read-only) |
<!-- END generated:mcp-domain-tools -->

## Result Envelope

Every tool returns JSON in both `content[0].text` and
`structuredContent`. Every advertised tool also carries the shared
output schema for this envelope so MCP clients can validate the shape
before calling tools.

Binary file exports are intentionally absent until MCP has a bounded resource
or file-safe transport. `clockify_shared_reports_view` accepts `JSON_V1` /
`JSON` and returns parsed JSON; use the SDK with an explicit file sink or
Clockify's own download link when a PDF or spreadsheet file is required.

Success:

```json
{
    "ok": true,
    "action": "clockify_create_work_package",
    "entity": "work_package",
    "ids": { "workspaceId": "...", "projectId": "...", "taskId": "..." },
    "data": {},
    "meta": { "workspaceId": "..." },
    "changed": {
        "created": [{ "type": "project", "id": "...", "name": "Website" }],
        "reused": [{ "type": "tag", "id": "...", "name": "Deep Work" }]
    },
    "next": [
        {
            "tool": "clockify_log_work",
            "args": { "project_id": "...", "task_id": "..." },
            "reason": "Log finished work against this package."
        }
    ]
}
```

Name resolution (`clarification`): when a name is passed where a
user/group/project id is expected and it is ambiguous or unknown, the
tool returns a success-shaped receipt that asks for disambiguation
instead of calling Clockify. `candidates` carries the real ids the
agent should pick from.

```json
{
    "ok": true,
    "action": "clockify_groups_add_member",
    "clarification": {
        "question": "Multiple users match \"Bob\". Which one?",
        "field": "userId",
        "candidates": [
            { "type": "user", "id": "...", "name": "Bob Lee" },
            { "type": "user", "id": "...", "name": "Bob Ng" }
        ]
    }
}
```

Recoverable error:

```json
{
    "ok": false,
    "action": "clockify_log_work",
    "error": { "code": "invalid_request", "message": "end is required" },
    "recovery": {
        "hint": "Check entry, project, task, tag, and time fields; use returned IDs or exact names.",
        "tool": "clockify_review_day"
    }
}
```

Stable error codes:

| Code | Meaning |
|---|---|
| `invalid_request` | Local validation or Clockify 400. |
| `auth_or_permission` | Clockify 401/403. |
| `feature_unavailable` | Plan-gated or unavailable Clockify feature. |
| `not_found` | Missing ID or unresolved exact match. |
| `conflict` | Clockify 409. |
| `rate_limited` | Clockify 429. |
| `clockify_upstream_error` | Clockify 5xx. |
| `connection_error` | Could not reach Clockify before any HTTP response (network/DNS/TLS). |
| `aborted` | The caller cancelled the request. |
| `rate_limited_retry_after` | Clockify 429 that named a `Retry-After` / `X-RateLimit-Reset` window. |
| `addon_token_restricted` | Add-on-token 401 on an endpoint outside the token's allowed surface. |
| `active_resource_delete_blocked` | Clockify 400 refusing a bare DELETE of an active project, task, or client. |
| `error` | Unknown local/runtime error. |
| `setup_required` | Server started without `CLOCKIFY_API_KEY` / `CLOCKIFY_WORKSPACE_ID`. |

The generated registry ([`docs/error-codes.md`](../docs/error-codes.md)) is the full list.

## Telemetry

`loadContext()` accepts SDK `composedFetch` hooks, so hosted callers or
tests can wire OpenTelemetry without forking the MCP server:

```ts
import { buildServer } from "@apet97/clockify-mcp-115/server";
import { loadContext } from "@apet97/clockify-mcp-115/client";
import { otelHooks } from "clockify-sdk-ts-115/otel-hooks";

const ctx = loadContext(process.env, {
    hooks: otelHooks({
        startSpan: (name, attrs) => tracer.startSpan(name, { attributes: attrs }),
    }),
});

const server = buildServer(ctx);
```

## TypeScript vs Go MCP

| | `@apet97/clockify-mcp-115` | `go-clockify` |
|---|---|---|
| Language | TypeScript / Node 22.13+ | Go |
| Transport | stdio | stdio |
| Tools | 162 | 156 |
| Strength | Node install, SDK-vendor style workflows, full domain CRUD | Drift gates, reports, raw API fallback, broader live evidence |
| Use when | You want a pure-JS Clockify MCP with workflow-complete daily use | You need the canonical, drift-gated reference server |

## Development

```sh
npm ci && make sdk-codegen              # from the repo root, once
npm run build -w clockify-sdk-ts-115    # build the workspace-linked SDK
cd mcp
npm install
npm run type-check
npm test
npm run build
npm pack --dry-run
```

Run live sandbox proof only through the repository-root orchestrator. It
requires an explicit match for the sacrificial workspace, supplies one
governed prefix, and emits a sanitized zero-leftover receipt:

```sh
cd ..
export CLOCKIFY_LIVE_WORKSPACE_CONFIRM="$CLOCKIFY_WORKSPACE_ID"
make perfect-live
```

Runtime tool-count smoke:

```sh
node dist/index.js <<<'{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}' \
  | jq '.result.tools | length'
```

## License

MIT
